package com.example.zad3_2_grebenukov.Data

data class Movie(
    val title: String,
    val description: String,
    val posterUrl: String
)