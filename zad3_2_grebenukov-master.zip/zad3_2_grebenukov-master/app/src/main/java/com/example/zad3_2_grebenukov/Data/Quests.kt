package com.example.zad3_2_grebenukov.Data

data class Quests(
    val image: Int,
    val title: String,
    val text: String
)
