package com.example.zad3_2_grebenukov.Data

import com.example.zad3_2_grebenukov.R

class MyObj(
    val list: ArrayList<Quests> = arrayListOf(
        Quests(
            R.drawable.kazan,
            "Welcome to Kazan",
            "Now you must go to Kazan Expo and find next key. And there are many more interesting information"
        ),
        Quests(
            R.drawable.kazan,
            "Welcome to Kazan",
            "Now you must go to Kazan Expo and find next key. And there are many more interesting information"
        ),
        Quests(
            R.drawable.kazan,
            "Welcome to Kazan",
            "Now you must go to Kazan Expo and find next key. And there are many more interesting information"
        ),
        Quests(
            R.drawable.kazan,
            "Welcome to Kazan",
            "Now you must go to Kazan Expo and find next key. And there are many more interesting information"
        ),
        Quests(
            R.drawable.kazan,
            "Welcome to Kazan",
            "Now you must go to Kazan Expo and find next key. And there are many more interesting information"
        ),
        Quests(
            R.drawable.kazan,
            "Welcome to Kazan",
            "Now you must go to Kazan Expo and find next key. And there are many more interesting information"
        )
    )
)